<?php

namespace App\Http\Controllers;

use App\Models\Tec;
use Illuminate\Http\Request;
use App\Http\Resources\TecResource;
use App\Http\Requests\StoreTec;

class TecController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return Tec::all();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreTec $request)
    {
      $validated = $request->validated();
      Tec::create($validated);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Tec  $tec
     * @return \Illuminate\Http\Response
     */
    public function show(Tec $tec)
    {
         return new TecResource($tec);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Tec  $tec
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Tec $tec)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Tec  $tec
     * @return \Illuminate\Http\Response
     */
    public function destroy(Tec $tec)
    {
        //
    }
}
