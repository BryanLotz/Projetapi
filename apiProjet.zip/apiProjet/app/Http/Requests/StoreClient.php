<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreClient extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [

            'idtec' => 'required|integer|exists:tecs,idtec',
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'adresse' => 'required|string|max:255',
            'marque' => 'required|string|max:255',
            'modele' => 'required|string|max:255',
            'numero' => 'required|string|max:255',
            'date_mise_service' => 'required|string|max:255',
            'date_inter' => 'required|string|max:255',
            'desc' => 'required|string|max:255',
            'tempsP' => 'required|string|max:255'
        ];
    }
}
