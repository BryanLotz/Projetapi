<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    use HasFactory;


    protected $fillable = [
        'idtec',
        'nom',
        'prenom',
        'adresse',
        'marque',
        'modele',
        'numero',
        'date_mise_service',
        'date_inter',
        'desc',
        'tempsP'
    ];

    public function tec()
    {
        return $this->belongsTo(Tec::class, 'idtec');
    }
}
