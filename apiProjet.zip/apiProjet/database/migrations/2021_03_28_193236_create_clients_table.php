<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateClientsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('clients', function (Blueprint $table) {
          $table->id();
          $table->unsignedBigInteger('idtec');
          $table->foreign('idtec')
          ->references('id')->on('tecs')
          ->onDelete('cascade');
          $table->string('nom');
          $table->string('prenom');
          $table->string('adresse');
          $table->string('marque');
          $table->string('modele');
          $table->string('numero');
          $table->string('date_mise_service');
          $table->string('date_inter');
          $table->string('desc');
          $table->string('tempsP');
          $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('clients');
    }
}
