package com.example.myproject.Model.Entity;

import java.sql.Date;
import java.sql.Time;
import java.util.HashMap;
import java.util.Map;

public class Client {

    private int id;
    private String idtec;
    private String nom;
    private String prenom;
    private String adresse;
    private String marque;
    private String modele;
    private String numero;
    private String date_mise_service;
    private String date_inter;
    private String desc;
    private String tempsP;
    private int envoie;




    public Client(int id, String idtec, String nom, String prenom, String numero, String adresse, String marque, String modele, String date_mise_service, String date_inter, String desc, String tempsP) {
        this.id = id;
        this.idtec = idtec;
        this.nom = nom;
        this.prenom = prenom;
        this.numero = numero;
        this.adresse = adresse;
        this.marque = marque;
        this.modele = modele;
        this.date_mise_service = date_mise_service;
        this.date_inter = date_inter;
        this.desc = desc;
        this.tempsP = tempsP;
        this.envoie = 0;
    }

    public Map<String, String> getMap(){
        Map<String, String> clientMap = new HashMap<>();
        clientMap.put("idtec", this.idtec);
        clientMap.put("nom", this.nom);
        clientMap.put("prenom", this.prenom);
        clientMap.put("adresse", this.adresse);
        clientMap.put("marque", this.marque);
        clientMap.put("modele", this.modele);
        clientMap.put("numero", this.numero);
        clientMap.put("date_mise_service", this.date_mise_service);
        clientMap.put("date_inter", this.date_inter);
        clientMap.put("desc", this.desc);
        clientMap.put("tempsP", this.tempsP);
        return clientMap;
    }

    public int getEnvoie() {
        return envoie;
    }

    public void setEnvoie(int envoie) {
        this.envoie = envoie;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIdtec() {
        return idtec;
    }

    public void setIdtec(String idtec) {
        this.idtec = idtec;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getMarque() {
        return marque;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }

    public String getModele() {
        return modele;
    }

    public void setModele(String modele) {
        this.modele = modele;
    }

    public String getDate_mise_service() {
        return date_mise_service;
    }

    public void setDate_mise_service(String date_mise_service) {
        this.date_mise_service = date_mise_service;
    }

    public String getDate_inter() {
        return date_inter;
    }

    public void setDate_inter(String date_inter) {
        this.date_inter = date_inter;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getTempsP() {
        return tempsP;
    }

    public void setTempsP(String tempsP) {
        this.tempsP = tempsP;
    }
}
