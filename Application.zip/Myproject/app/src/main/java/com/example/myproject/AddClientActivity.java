package com.example.myproject;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myproject.Model.DAO.ClientManager;
import com.example.myproject.Model.Entity.Client;

import androidx.appcompat.app.AppCompatActivity;

public class AddClientActivity extends AppCompatActivity {

    private Button madd;
    private ClientManager clientManager;
    private EditText mNom,mPrenom,mNumero,etidtec,madresse,mmarque,mmodele,etdateMS,etdateI,mnum,mdesc,mtime;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_client);

        madd = (Button) findViewById(R.id.addcontactButton);
        mNom = (EditText) findViewById(R.id.nom);
        mPrenom = (EditText) findViewById(R.id.leprenom);
        etidtec = (EditText) findViewById(R.id.etidtec);
        madresse = (EditText) findViewById(R.id.adresse);
        mmarque = (EditText) findViewById(R.id.etmarque);
        mmodele = (EditText) findViewById(R.id.etmodele);
        etdateMS = (EditText) findViewById(R.id.etdateMS);
        etdateI = (EditText) findViewById(R.id.etdateI);
        mnum = (EditText) findViewById(R.id.etnum);
        mdesc = (EditText) findViewById(R.id.etdesc);
        mtime = (EditText) findViewById(R.id.ettime);


        clientManager = new ClientManager(this);
        madd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Ouvre l'acces a la base de données
                clientManager.open();

                //Crée un nouveau contact et peuple l'objet avec les valeurs des champs de l'activité
                Client newContact = new Client(0,"","","","","","","","","","","");
                newContact.setIdtec(etidtec.getText().toString());
                newContact.setNom(mNom.getText().toString());
                newContact.setPrenom(mPrenom.getText().toString());
                newContact.setAdresse(madresse.getText().toString());
                newContact.setMarque(mmarque.getText().toString());
                newContact.setModele(mmodele.getText().toString());
                newContact.setNumero(mnum.getText().toString());
                newContact.setDate_mise_service(etdateMS.getText().toString());
                newContact.setDate_inter(etdateI.getText().toString());
                newContact.setDesc(mdesc.getText().toString());
                newContact.setTempsP(mtime.getText().toString());



                //Ajoute le contact à la base de données
                clientManager.addClient(newContact);

                // Ferme l'acces a la base
                clientManager.close();

                // Ferme l'activité une fois l'ajout terminé.
                AddClientActivity.this.finish();
            }
        });
    }
}
