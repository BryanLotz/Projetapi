package com.example.myproject;

import android.content.Intent;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.myproject.Model.DAO.ClientManager;
import com.example.myproject.Model.Entity.Client;
import com.example.myproject.NetworkService.AsyncJSONData;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.myproject.Model.DataAdapter.ClientListAdapter;
import com.example.myproject.NetworkService.AsyncPostJSONData;

import java.util.ArrayList;

public class DataActivity extends AppCompatActivity {

    private Button mbuttonAddData, btenvoie;
    private ArrayList<Client> contactList;
    // On déclare l'adapteur nécessaire pour lié les datas a la Recycler View
    com.example.myproject.Model.DataAdapter.ClientListAdapter adapter;
    private ClientManager clientManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        // On créer un ContactManager pour pouvoir récupérer la liste de contact
        clientManager = new ClientManager(this);

        // on se connecte à la base de données
        clientManager.open();

        // On récupère la liste de contacts contenus dans la table Contact
        contactList = clientManager.getClient();

        // on ferme la connexion
        clientManager.close();

        //on lie les elements d'interface aux objets correspondants
        mbuttonAddData = (Button) findViewById(R.id.buttonAddData);
        btenvoie = (Button) findViewById(R.id.btenvoie);

        /*AsyncJSONData task = new AsyncJSONData(DataActivity.this);
        task.execute("http://lakartxela.iutbayonne.univ-pau.fr/~blotz/apiProjet/public/api/clients");*/

        mbuttonAddData.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent AddContactActivity = new Intent(DataActivity.this, AddClientActivity.class);
                startActivity(AddContactActivity);
            }
        });
        btenvoie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clientManager.open();
                for(int i=0; i< contactList.size();i++ ){

                    if(contactList.get(i).getEnvoie() == 0){
                        Log.d("hasmap", contactList.get(i).getMap().toString());
                        AsyncPostJSONData task = new AsyncPostJSONData(contactList.get(i).getMap());
                        task.execute("http://lakartxela.iutbayonne.univ-pau.fr/~blotz/apiProjet/public/api/clients");

                        contactList.get(i).setEnvoie(1);
                        clientManager.updateContact(contactList.get(i));
                    }

                }
                contactList.clear();
                contactList.addAll(clientManager.getClient());
                adapter.notifyDataSetChanged();

                clientManager.close();
            }

        });


        // On parametre notre vue Recycler en liant son id
        RecyclerView recyclerView = findViewById(R.id.MyrvData);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // On lie maintenant les données à notre adapteur
        adapter = new com.example.myproject.Model.DataAdapter.ClientListAdapter(this, contactList);

        // On ajoute la gestion des evenements sur le clic
        //adapter.setClickListener(this);

        // Puis on lie notre adapteur au RecyclerView
        recyclerView.setAdapter(adapter);

        // On ajoute un trait de séparation entre les éléments (pour faciliter la lecture et le clic
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(),1);
        recyclerView.addItemDecoration(dividerItemDecoration);
    }

    /*@Override
    public void onItemClick(View view, int position) {
        //On utilise Toast (https://developer.android.com/reference/android/widget/Toast) et sa méthode makeText pour afficher le texte correspondant à l'élément cliqué.
        Toast.makeText(this, "Vous avez cliqué sur " + adapter.getItem(position).getNom() + " " + adapter.getItem(position).getPrenom()  + " à la ligne " + position, Toast.LENGTH_SHORT).show();
        // ou tout autre traitement de notre choix sur le clic
    }*/



    @Override
    protected void onRestart() {
        super.onRestart();

        //On vide la liste
        contactList.clear();

        clientManager.open();

        //Puis on réajoute tout le contenu de la liste de la base
        contactList.addAll(clientManager.getClient());

        clientManager.close();

        // indique a l'adapter que les données ont été mise à jour,
        // et que le contenu de recyclerView doit être réaffiché.
        adapter.notifyDataSetChanged();
    }
}
