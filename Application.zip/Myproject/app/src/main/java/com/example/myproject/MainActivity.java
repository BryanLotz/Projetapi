package com.example.myproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {


        private TextView mletexte;

        private EditText etid,etmdp;

        private Button boutonCo;



        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            mletexte = (TextView) findViewById(R.id.monTexte);
            etid = (EditText) findViewById(R.id.etid);
            etmdp = (EditText) findViewById(R.id.etmdp);
            boutonCo = (Button) findViewById(R.id.boutonCo);

            //boutonCo.setEnabled(false);

            boutonCo.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Intent DataActivity = new Intent(MainActivity.this, DataActivity.class);
                    startActivity(DataActivity);
                }
            });
        }
    }

