package com.example.myproject.Model.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.myproject.Model.TheSQLiteDB;
import com.example.myproject.Model.Entity.Client;

import java.sql.Date;
import java.util.ArrayList;

public class ClientManager {

    private static final String TABLE_NAME = "client";
    public static final String KEY_ID_CLIENT= "id";
    public static final String KEY_IDTEC_CLIENT="idtec";
    public static final String KEY_NOM_CLIENT="nom";
    public static final String KEY_PRENOM_CLIENT="prenom";
    public static final String KEY_NUMERO_CLIENT="numero";
    public static final String KEY_ADRESSE_CLIENT="adresse";
    public static final String KEY_MARQUE_CLIENT="marque";
    public static final String KEY_MODELE_CLIENT="modele";
    public static final String KEY_DATEMS_CLIENT="date_mise_service";
    public static final String KEY_DATEI_CLIENT="date_inter";
    public static final String KEY_DESC_CLIENT="desc";
    public static final String KEY_TEMPSP_CLIENT="tempsP";


    public static final String CREATE_TABLE_CONTACT = "CREATE TABLE "+TABLE_NAME+
            " (" +
            " "+KEY_ID_CLIENT+" INTEGER primary key," +
            " "+KEY_IDTEC_CLIENT+" TEXT," +
            " "+KEY_NOM_CLIENT+" TEXT," +
            " "+KEY_PRENOM_CLIENT+" TEXT," +
            " "+KEY_ADRESSE_CLIENT+" TEXT," +
            " "+KEY_NUMERO_CLIENT+" TEXT," +
            " "+KEY_MARQUE_CLIENT+" TEXT," +
            " "+KEY_MODELE_CLIENT+" TEXT," +
            " "+KEY_DATEMS_CLIENT+" TEXT," +
            " "+KEY_DATEI_CLIENT+" TEXT," +
            " "+KEY_DESC_CLIENT+" TEXT," +
            " "+KEY_TEMPSP_CLIENT+" TEXT" +
            ");";
    private TheSQLiteDB maBase; // notre gestionnaire du fichier SQLite
    private SQLiteDatabase db;

    // Constructeur
    public ClientManager(Context context)
    {
        maBase = TheSQLiteDB.getInstance(context);
    }

    public void open()
    {
        //on ouvre la table en lecture/écriture
        db = maBase.getWritableDatabase();
    }

    public void close()
    {
        //on ferme l'accès à la BDD
        db.close();
    }

    public long addClient(Client contact) {
        // Ajout d'un enregistrement dans la table

        ContentValues values = new ContentValues();
        values.put(KEY_IDTEC_CLIENT, contact.getIdtec());
        values.put(KEY_NOM_CLIENT, contact.getNom());
        values.put(KEY_PRENOM_CLIENT, contact.getPrenom());
        values.put(KEY_ADRESSE_CLIENT, contact.getAdresse());
        values.put(KEY_MARQUE_CLIENT, contact.getMarque());
        values.put(KEY_MODELE_CLIENT, contact.getModele());
        values.put(KEY_NUMERO_CLIENT, contact.getNumero());
        values.put(KEY_DATEMS_CLIENT, contact.getDate_mise_service());
        values.put(KEY_DATEI_CLIENT, contact.getDate_inter());
        values.put(KEY_DESC_CLIENT, contact.getDesc());
        values.put(KEY_TEMPSP_CLIENT, contact.getTempsP());


        // insert() retourne l'id du nouvel enregistrement inséré, ou -1 en cas d'erreur
        return db.insert(TABLE_NAME,null,values);
    }

    public int updateContact(Client contact) {
        // modification d'un enregistrement
        // valeur de retour : (int) nombre de lignes affectées par la requête

        ContentValues values = new ContentValues();
        values.put(KEY_NOM_CLIENT, contact.getNom());

        String where = KEY_ID_CLIENT+" = ?";
        String[] whereArgs = {contact.getId()+""};

        return db.update(TABLE_NAME, values, where, whereArgs);
    }

    public int removeContact(Client contact) {
        // suppression d'un enregistrement
        // valeur de retour : (int) nombre de lignes affectées par la clause WHERE, 0 sinon

        String where = KEY_ID_CLIENT+" = ?";
        String[] whereArgs = {contact.getId()+""};

        return db.delete(TABLE_NAME, where, whereArgs);
    }

    public Client getClient(int id) {
        // Retourne l'animal dont l'id est passé en paramètre

        Client a=new Client(0,"","","","","","","","","","","");

        Cursor c = db.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE "+KEY_ID_CLIENT+"="+id, null);

        if (c.moveToFirst()) {
            a.setId(c.getInt(c.getColumnIndex(KEY_ID_CLIENT)));
            a.setIdtec(c.getString(c.getColumnIndex(KEY_IDTEC_CLIENT)));
            a.setNom(c.getString(c.getColumnIndex(KEY_NOM_CLIENT)));
            a.setPrenom(c.getString(c.getColumnIndex(KEY_PRENOM_CLIENT)));
            a.setAdresse(c.getString(c.getColumnIndex(KEY_ADRESSE_CLIENT)));
            a.setMarque(c.getString(c.getColumnIndex(KEY_MARQUE_CLIENT)));
            a.setModele(c.getString(c.getColumnIndex(KEY_MODELE_CLIENT)));
            a.setNumero(c.getString(c.getColumnIndex(KEY_NUMERO_CLIENT)));
            a.setDate_inter(c.getString(c.getColumnIndex(KEY_DATEI_CLIENT)));
            a.setDate_mise_service(c.getString(c.getColumnIndex(KEY_DATEMS_CLIENT)));
            a.setDesc(c.getString(c.getColumnIndex(KEY_DESC_CLIENT)));
            a.setTempsP(c.getString(c.getColumnIndex(KEY_TEMPSP_CLIENT)));

            c.close();
        }

        return a;
    }

    public ArrayList<Client> getClient() {

        ArrayList<Client> clientList = new ArrayList<Client>();

        //récupère dans un curseur le résultat du select sur la table
        Cursor c = db.rawQuery("SELECT * FROM "+TABLE_NAME, null);

        if (c.moveToFirst()) {
            //parcourt le curseur obtenu, jusqu'a la fin, et créer pour chaque enregistrement un objet Contact
            do {
                Client a = new Client(0, "","","","","","","","","","","");
                a.setId(c.getInt(c.getColumnIndex(KEY_ID_CLIENT)));
                a.setIdtec(c.getString(c.getColumnIndex(KEY_IDTEC_CLIENT)));
                a.setNom(c.getString(c.getColumnIndex(KEY_NOM_CLIENT)));
                a.setPrenom(c.getString(c.getColumnIndex(KEY_PRENOM_CLIENT)));
                a.setAdresse(c.getString(c.getColumnIndex(KEY_ADRESSE_CLIENT)));
                a.setNumero(c.getString(c.getColumnIndex(KEY_NUMERO_CLIENT)));
                a.setMarque(c.getString(c.getColumnIndex(KEY_MARQUE_CLIENT)));
                a.setModele(c.getString(c.getColumnIndex(KEY_MODELE_CLIENT)));
                a.setDate_mise_service(c.getString(c.getColumnIndex(KEY_DATEMS_CLIENT)));
                a.setDate_inter(c.getString(c.getColumnIndex(KEY_DATEI_CLIENT)));
                a.setDesc(c.getString(c.getColumnIndex(KEY_DESC_CLIENT)));
                a.setTempsP(c.getString(c.getColumnIndex(KEY_TEMPSP_CLIENT)));


                // ajoute l'objet créé à la ArrayList de Contact qui sera renvoyée.
                clientList.add(a);
            }
            while (c.moveToNext());
        }
        c.close();

        return clientList;
    }
}
