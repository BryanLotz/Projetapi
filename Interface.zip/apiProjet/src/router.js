import { createRouter, createWebHistory } from 'vue-router';
import Home from './views/Home.vue';
import Interventions from './views/interventions.vue';
import Tecs from './views/tec.vue';
import Client from './views/client.vue';
import Tec from './views/untec.vue';
import newTec from './views/createTec.vue';

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home,
  },
  {
    path: '/inter',
    name: 'interventions',
    component: Interventions,
  },
  {
    path: '/tec',
    name: 'tecniciens',
    component: Tecs,
  },
  {
    path: '/newtec',
    name: 'newtec',
    component: newTec,
  },
  
  
  { path: '/unclient/:id', name: 'Client', component: Client, props: true },
  { path: '/untec/:id', name: 'Tec', component: Tec, props: true }
  
];

const router = createRouter({
  routes,
  history: createWebHistory(),
  linkActiveClass: 'active',
});

export default router;