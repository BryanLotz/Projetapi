import { createRouter, createWebHistory } from 'vue-router';
import Home from './views/Home.vue';
import Interventions from './views/interventions.vue';
import Tecs from './views/tec.vue';
import Client from './views/client.vue';

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home,
  },
  {
    path: '/inter',
    name: 'interventions',
    component: Interventions,
  },
  {
    path: '/tec',
    name: 'tecniciens',
    component: Tecs,
  },
  /*{
    path: '/page1',
    name: 'Page 1',
    component: Page1,
  },
  {
    path: '/page2',
    name: 'Page 2',
    component: Page2,
  },*/
  
  { path: '/unclient/:id', name: 'Client', component: Client, props: true }
];

const router = createRouter({
  routes,
  history: createWebHistory(),
  linkActiveClass: 'active',
});

export default router;