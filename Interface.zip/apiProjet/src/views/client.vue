<template>

<h3>Mme, Mr {{client.nom}}</h3>

<ul class="list-group list-group-flush">
  <li class="list-group-item">Id : {{client.id}}</li>
  <li class="list-group-item">Nom : {{client.nom}}</li>
  <li class="list-group-item">Prénom : {{client.prenom}}</li>
  <li class="list-group-item">Technicien : {{client.idtec}}</li>
  <li class="list-group-item">Adresse : {{client.adresse}}</li>
  <li class="list-group-item">Marque : {{client.marque}}</li>
  <li class="list-group-item">Modèle : {{client.modele}}</li>
  <li class="list-group-item">Numéro : {{client.numero}}</li>
  <li class="list-group-item">Date Mise en Service : {{client.date_mise_service}}</li>
  <li class="list-group-item">Date Intervention : {{client.date_inter}}</li>
  <li class="list-group-item">Description : {{client.desc}}</li>
  <li class="list-group-item">Temps passé : {{client.tempsP}}</li>
  
</ul>



</template>

<script>
import api from '../api.js';
export default {
  props: ['id'],
  data() {
    return {
      loading: false,
      client: "",
    };
  },
  mounted() {
    this.refreshDoodle();
  },
  methods: {
    refreshDoodle() {
      this.loading = true;
      api.get('clients/' + this.id, { params: { expand: 'paths' } })
        .then(response => {
          this.client = response.data.data;
        })
        .finally(() => {
          this.loading = false;
        });
    }
  }
};
</script>