<template>
<ul class="list-group list-group-flush">
  <li class="list-group-item">{{client.id}}</li>
  <li class="list-group-item">{{client.nom}}</li>
  <li class="list-group-item">{{client.prenom}}</li>
  <li class="list-group-item">{{client.idtc}}</li>
  <li class="list-group-item">{{client.adresse}}</li>
  <li class="list-group-item">{{client.marque}}</li>
  <li class="list-group-item">{{client.modele}}</li>
  <li class="list-group-item">{{client.numero}}</li>
  <li class="list-group-item">{{client.date_mise_service}}</li>
  <li class="list-group-item">{{client.date_inter}}</li>
  <li class="list-group-item">{{client.tempsP}}</li>

</ul>



</template>

<script>
import api from '../api.js';
export default {
  props: ['id'],
  data() {
    return {
      loading: false,
      client: "",
    };
  },
  mounted() {
    this.refreshDoodle();
  },
  methods: {
    refreshDoodle() {
      this.loading = true;
      api.get('clients/' + this.id, { params: { expand: 'paths' } })
        .then(response => {
          this.client = response.data.data;
        })
        .finally(() => {
          this.loading = false;
        });
    }
  }
};
</script>