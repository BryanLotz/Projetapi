<template>
<div class="container">
<router-link to="/">
<img class="logoback" src="back.png" alt="">
<div class="test"></div>
</router-link>
    <h3>Techniciens</h3>
    <router-link to="/newtec"><h4 class="font-weight-light" style="float:right;">Ajouter un Technicien</h4></router-link>
    
    <table class="table">
    <thead>
        <tr>
        <th scope="col">id</th>
        <th scope="col">Nom</th>
        

        </tr>
    </thead>
    <tbody>
        <tr v-for="untec in datatecs" :key="untec.id">
            <td>{{untec.id}}</td>
            <td>{{untec.nom}}</td>
            <td> <router-link :to="{ name: 'Tec', params: { id: untec.id } }">
                <button type="button" class="btn btn-info">Ses interventions</button>
                </router-link>
            </td>
        </tr>
       
    </tbody>
    </table>
  </div>
</template>
<script>
import api from '../api.js';

export default {
  data() {
    return {
      nomS : "",
      loading: false,
      datatecs: [],
    };
  },
  mounted() {
    this.refreshTecs();
    
  },
  methods: {
    refreshTecs() {
      this.loading = true;
      api.get('tecs')
        .then(response => {
          this.datatecs = response.data;
          console.log(response.data);
        })
        .finally(() => {
          this.loading = false;
        });
    }
      
      
    }
  
};
</script>