<template>
<form>
      <div class="mb-3">
        <label for="nom" class="form-label">Nom</label>
        <input v-model="nom" type="text" class="form-control" id="nom" required />
        <div class="invalid-feedback">Nom invalide</div>
      </div>
      <button type="submit" class="btn btn-primary">Enregistrer</button>
    </form>
  
</template>
<script>
import api from '../api.js';

export default {
  data() {
    return {
      nom : "",
      loading: false,
      
    };
  },
methods: {
    onSubmit() {
            api.post('tecs', { nom: this.nom })
            .then(response => {
                resolve(response.data);
                })
                .catch(error => {
                reject(error);

                }).finally(() => {
                commit('loading', false);
                });  
    },
  },
};
</script>