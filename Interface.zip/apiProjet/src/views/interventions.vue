<template>
  <div class="container">
  <router-link to="/">
<img class="logoback" src="back.png" alt="">
<div class="test"></div>
</router-link>
    <h3>Interventions</h3>
    <div class="input-group rounded">
      <input type="search" v-model="nomS" class="form-control rounded" placeholder="Rechercher par Nom de client" aria-label="Search"
       aria-describedby="search-addon" />
      <span v-on:click="refreshClients" class="input-group-text border-0" id="search-addon" >
        <i class="fas fa-search"></i>
      </span>
    </div>
    <table class="table">
    <thead>
        <tr>
        <th scope="col">id</th>
        <th scope="col">Nom</th>
        <th scope="col">Prenom</th>
        <th scope="col">idtec</th>
        <th scope="col">Adresse</th>
        <th scope="col">Date Intervention</th>

        </tr>
    </thead>
    <tbody>
        <tr v-for="unclient in dataclients" :key="unclient.id">
            <td>{{unclient.id}}</td>
            <td>{{unclient.nom}}</td>
            <td>{{unclient.prenom}}</td>
            <td>{{unclient.idtec}}</td>
            <td>{{unclient.adresse}}</td>
            <td>{{unclient.date_inter}}</td>
            <td><router-link :to="{ name: 'Client', params: { id: unclient.id } }">
            <button type="button" class="btn btn-info">Details</button>
            </router-link></td>
        </tr>
       
    </tbody>
    </table>
  </div>
</template>



<script>
import api from '../api.js';

export default {
  data() {
    return {
      nomS : "",
      loading: false,
      dataclients: [],
    };
  },
  mounted() {
    this.refreshClients();
    
  },
  methods: {
    refreshClients() {
      this.loading = true;
      if(this.nomS){
        api.get('clients')
        .then(res => {
          if (this.nomS) {
            this.dataclients = res.data.filter(unclient =>
              unclient.nom.toLowerCase().includes(this.nomS.toLowerCase())
            );
          } else {
            this.dataclients = res.results.data;
          }
        })
        .finally(() => {
          this.loading = false;
        });
      }else{
        api.get('clients')
        .then(response => {
          this.dataclients = response.data;
          
        })
        .finally(() => {
          this.loading = false;
        });
      }
      
    }
  }
};
</script>