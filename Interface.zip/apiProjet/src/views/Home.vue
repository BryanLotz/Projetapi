<template>  
<div class="container">
  <div class="row">
    <div class="col-sm">
    <router-link to="/tec">
      <div class="card text-white bg-info mb-3" style="max-width: 18rem;">
        <div class="card-header"><h3>Tecniciens</h3></div>
            <img class="card-img-top" src="capi.jpg" alt="Card image cap">
                <div class="card-body">     
                </div>
        </div>
    
    </router-link>
    </div>
    <div class="col-sm">
      
    </div>
    <div class="col-sm">
    <router-link to="/inter" >
        <div class="card text-white bg-success mb-3" style="width: 18rem;">
            <div class="card-header"><h3>Interventions</h3></div>
                <img class="card-img-top" src="client.png" alt="Card image cap">
                    <div class="card-body">
                        
                    </div>
            
        </div>
    </router-link>
    </div>
  </div>
</div>
    

       
        
          
</template>