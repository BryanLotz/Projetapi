<template>
<router-link to="/tec">
<img class="logoback" src="back.png" alt="">

</router-link>
<h3>Technicien {{tec.nom}}</h3>
<ul class="list-group list-group-flush">
  <li class="list-group-item">Id : {{tec.id}}</li>
  <li class="list-group-item">Nom : {{tec.nom}}</li>
  <br/>
  <center><h3>Interventions réalisé</h3> </center>
  <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">Nom</th>
      <th scope="col">Prénom</th>
      <th scope="col">Adresse</th>
      <th scope="col">Date Mise en Service</th>
      <th scope="col">Date Intervention</th>
    </tr>
  </thead>
  <tbody>
    <tr v-for="unclient in tecclient">
    <td>{{unclient.id}}</td>
    <td>{{unclient.nom}}</td>
    <td>{{unclient.prenom}}</td>
    <td>{{unclient.adresse}}</td>
    <td>{{unclient.date_mise_service}}</td>
    <td>{{unclient.date_inter}}</td>
    <td> <router-link :to="{ name: 'Client', params: { id: unclient.id } }">
                <button type="button" class="btn btn-info">Details</button>
                </router-link>
            </td>
  </tr>
  </tbody>
</table>
  
  

</ul>



</template>

<script>
import api from '../api.js';
export default {
  props: ['id'],
  data() {
    return {
      loading: false,
      tec: "",
      tecclient: [],
    };
  },
  mounted() {
    this.refreshTec();
    this.getClient();
  },
  methods: {
    refreshTec() {
      this.loading = true;
      api.get('tecs/' + this.id,)
        .then(response => {
          this.tec = response.data.data;
        })
        .finally(() => {
          this.loading = false;
        });
    },
    getClient(){
      api.get('clients', { params: { idtec: this.tec.id } })
        .then(response => {
          this.tecclient = response.data;
          console.log(this.tecclient);
        })
        .finally(() => {
          this.loading = false;
        });
    }
    
  }
};
</script>