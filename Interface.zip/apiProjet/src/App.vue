<template>
  <div>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-main">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbar-main">
          <div class="navbar-nav">
            <router-link to="/" class="navbar-brand"><h1>Les chaudières sanzot</h1></router-link>
          </div>
          
          
        </div>
      </div>
    </nav>
    <div class="container mt-4">
      
      <router-view v-slot="{ Component }">
            <transition
              name="custom-classes-transition"
              enter-active-class="animate__animated animate__fadeInLeft"
              leave-active-class="animate__animated animate__fadeOutRight"
              mode="out-in">
              <component :is="Component" />
            </transition>
          </router-view>
    </div>
  </div>
</template>

<script>
const pages = {
  accueil: {
    title: 'Interventions'
  },
  
};

export default {
  data() {
    return {
      currentPage: 'accueil'
    }
  },
  computed: {
    title() {
      return pages[this.currentPage].title;
    },
  },
  methods: {
    page(id) {
      this.currentPage = id;
    }
  }
}
</script>

<style>
</style>