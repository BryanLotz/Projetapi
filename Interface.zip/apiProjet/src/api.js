import axios from 'axios';

const api = axios.create({
  baseURL: 'http://lakartxela.iutbayonne.univ-pau.fr/~blotz/apiProjet/public/api/',
});

export default api;